package crud.prontuario.exception;

public class PacienteJaCadastradoException extends Exception{

	private static final long serialVersionUID = 1L;
	
	public PacienteJaCadastradoException(String msg) {
		super(msg);
	}
}
